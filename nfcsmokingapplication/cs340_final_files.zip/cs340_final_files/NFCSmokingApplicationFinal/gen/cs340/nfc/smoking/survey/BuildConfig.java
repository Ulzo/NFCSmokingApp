/** Automatically generated file. DO NOT MODIFY */
package cs340.nfc.smoking.survey;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}